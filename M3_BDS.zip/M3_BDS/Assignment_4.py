#The purpos of this code is to create a streamlit app, that can utilize docker, flowize, openai and neo4j to create an app that can answer the following assignment:
#1. Automated Economic Analysis Agent
#Description
#Develop an AI agent that autonomously collects economic data from various sources.
#Requirements
#Utilize GPT models to analyze the collected data and generate insights or summaries.
#Implement features that allow the agent to answer user queries about the data.
#Knowledge Graph Integration: Map the analyzed data and insights into a knowledge graph to visualize relationships and dependencies.

#The knowledge graph is gonna be implemented in neo4j, where data is taken from the s&p 500 using yahoo finance data and tickers from wikipedia.
#To create information about the plots and data openai api is used.
#To generate general questions flowize is used

#########We start the code by importing the necessary libraries
import streamlit as st
import yfinance as yf
import openai
import requests
import pandas as pd
import matplotlib.pyplot as plt
import networkx as nx
from datetime import datetime
import plotly.graph_objects as go
import uuid
from neo4j import GraphDatabase
import pytz
import torch
from torch_geometric.data import Data
import numpy as np

#########Then we setup a cennection to neo4j 
uri = ""  #Replace with uri from neo4j instance
username = "neo4j"
password = ""  #Replace with pasword from neo4j
driver = GraphDatabase.driver(uri, auth=(username, password))

#########Seting up connection to flowize agent
API_URL = ""

#########Setting up the connection to api 
OPENAI_API_KEY = "" #Replace with api key from open ai
openai.api_key = OPENAI_API_KEY


#Title of the streamlit aplication
st.title("Automated Economic Analysis for Top 100 Grossing S&P 500 Firms")

######### using wikipedia to get s&p 500 tickers
@st.cache_data
def fetch_sp500_tickers():
    url = 'https://en.wikipedia.org/wiki/List_of_S%26P_500_companies'
    tables = pd.read_html(url)
    sp500_table = tables[0]
    return sp500_table['Symbol'].tolist()

tickers = fetch_sp500_tickers()

######### using these tickers to Fetch Market Capitalization Data based on the companies wikipedia has listed as being in the s&p500
@st.cache_data
def fetch_market_caps(tickers):
    market_caps = {}
    for ticker in tickers:
        try:
            stock = yf.Ticker(ticker)
            info = stock.info
            market_caps[ticker] = info.get("marketCap", 0)
        except Exception as e:
            st.warning(f"Error fetching market cap for {ticker}: {e}")
    market_caps_df = pd.DataFrame(list(market_caps.items()), columns=["Ticker", "MarketCap"])
    market_caps_df = market_caps_df.sort_values(by="MarketCap", ascending=False).head(100)
    return market_caps_df

######### Using the ticker and defined start_data and end_date chosen by the user to Fetch Historical Stock Data. We wanted the user to select the range since this have an effect on the plots and feedback created by the ai agent. 
@st.cache_data
def fetch_stock_data(tickers, start_date, end_date):
    combined_data = {}
    for ticker in tickers:
        try:
            stock = yf.Ticker(ticker)
            data = stock.history(start=start_date, end=end_date)
            if not data.empty:
                combined_data[ticker] = data['Close'] 
        except Exception as e:
            st.warning(f"Error fetching data for {ticker}: {e}")
    return pd.DataFrame(combined_data)

######### Using Stock Data to Identify the Top 5 stocks to Buy and Sell given the information in the stock data
def analyze_stocks_for_buy_and_sell(stock_data):
    performance = (stock_data.iloc[-1] - stock_data.iloc[0]) / stock_data.iloc[0] * 100
    top_to_buy = performance.sort_values(ascending=False).head(5)
    top_to_sell = performance.sort_values(ascending=True).head(5)
    return top_to_buy, top_to_sell

######### Using openai to generate explenations to why the 5 tickers is either a buy or sell
def generate_openai_explanation(top_to_buy, top_to_sell):
    prompt = (
        f"Analyze the following stock recommendations:\n\n"
        f"Top 5 Stocks to Buy:\n{top_to_buy.to_string()}\n\n"
        f"Top 5 Stocks to Sell:\n{top_to_sell.to_string()}\n\n"
        "Provide reasons for each recommendation based on market trends and performance."
    )
    try:
        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",
            messages=[
                {"role": "system", "content": "You are an AI financial analyst."},
                {"role": "user", "content": prompt}
            ]
        )
        return response['choices'][0]['message']['content']
    except Exception as e:
        return f"Error generating explanation: {e}"

######### using stock data and the correlation between the data to generate GNN graph data
def enhance_graph_for_gnn(stock_data, correlation_threshold=0.8):
    correlation_matrix = stock_data.corr() #calculates the correlation and creates the correlation matrix
    nx_graph = nx.Graph() #Setting up the network graph
    for ticker in stock_data.columns: #Create notes 
        nx_graph.add_node(ticker)
    for i, ticker1 in enumerate(stock_data.columns): #Creates endges
        for j, ticker2 in enumerate(stock_data.columns):
            if i < j:
                correlation = correlation_matrix.loc[ticker1, ticker2]
                if correlation > correlation_threshold:
                    nx_graph.add_edge(ticker1, ticker2)
    node_features = {}
    for ticker in stock_data.columns:
        changes = (stock_data[ticker].iloc[-1] - stock_data[ticker].iloc[0]) / stock_data[ticker].iloc[0]
        node_features[ticker] = [changes]
    pyg_data = convert_to_pyg_data(nx_graph, node_features=node_features) # Convert to PyTorch Geometric Data
    return pyg_data

######### Using the PyTorch package to convert the networkx graph from above into PyTorch Geometric Data format
def convert_to_pyg_data(nx_graph, node_features=None):  
    """
    Converts a NetworkX graph to PyTorch Geometric Data format.

    Args:
        nx_graph (networkx.Graph): The input NetworkX graph.
        node_features (dict or None): Optional dictionary of node features. Keys should match node labels in the graph.

    Returns:
        torch_geometric.data.Data: Graph data in PyTorch Geometric format.
    """
      
    node_mapping = {node: i for i, node in enumerate(nx_graph.nodes())} # Is used to map node labels into numeric indices
    edge_index = torch.tensor(     # Is used to convert edges into numeric indices
        [[node_mapping[u], node_mapping[v]] for u, v in nx_graph.edges], dtype=torch.long
    ).t().contiguous()
    if node_features: #Is used to create node features
        features = []
        for node in nx_graph.nodes():
            features.append(node_features.get(node, np.zeros(10)))  # Default to zero vector if no features
        x = torch.tensor(features, dtype=torch.float)
    else:
        x = torch.eye(len(nx_graph.nodes()), dtype=torch.float)  # Default to identity matrix if no features provided
    data = Data(x=x, edge_index=edge_index) # PyTorch Geometric Data object
    return data

######### The following is used to push Graph Data to Neo4j
def add_node(tx, node_label, node_properties): #This function helps to add nodes to the data
    ticker = node_properties.get("ticker") or node_properties.get("label")
    if not ticker:
        raise KeyError("Node properties must include a 'ticker' or 'label' key")
    query = f"""
    MERGE (n:{node_label} {{ticker: $ticker}})
    SET n += $properties
    """
    tx.run(query, ticker=ticker, properties=node_properties)

def add_relationship(tx, ticker1, ticker2, correlation): #Adds the relationship between tickers
    query = """
    MATCH (a {ticker: $ticker1}), (b {ticker: $ticker2})
    MERGE (a)-[r:CORRELATED {correlation: $correlation}]->(b)
    """
    tx.run(query, ticker1=ticker1, ticker2=ticker2, correlation=correlation)

def push_graph_to_neo4j(graph): #Pushes the information gathered to neo4j
    with driver.session() as session:
        for node in graph.nodes(data=True):
            session.write_transaction(add_node, "Stock", {"ticker": node[0]})
        for edge in graph.edges(data=True):
            ticker1, ticker2, attributes = edge
            correlation = attributes.get('weight', 0)
            session.write_transaction(add_relationship, ticker1, ticker2, correlation)

######### Function to get data to use in the knowledge graph
def fetch_metadata(tickers):
    metadata = {}
    for ticker in tickers:
        try:
            stock = yf.Ticker(ticker)
            info = stock.info
            metadata[ticker] = {
                "industry": info.get("industry", "Unknown"),
                "sector": info.get("sector", "Unknown"),
                "market_cap": info.get("marketCap", 0),
                "country": info.get("country", "Unknown"),
            }
        except Exception as e:
            st.warning(f"Error fetching metadata for {ticker}: {e}")
    return metadata


######### Functions to create and handle the knowledge graph
def create_knowledge_graph(stock_data, metadata):
    graph = nx.MultiDiGraph()  # MultiDiGraph for multiple relationship types
    # Add nodes with metadata, ensuring the 'ticker' key is present
    for ticker, info in metadata.items():
        graph.add_node(
            ticker,
            ticker=ticker,  # Explicitly set the 'ticker' key
            label="Company",
            industry=info.get("industry"),
            sector=info.get("sector"),
            market_cap=info.get("market_cap"),
            country=info.get("country"),
        )
    # Add correlation relationships
    correlation_matrix = stock_data.corr()
    for i, ticker1 in enumerate(stock_data.columns):
        for j, ticker2 in enumerate(stock_data.columns):
            if i < j:
                correlation = correlation_matrix.loc[ticker1, ticker2]
                if correlation > 0.8:
                    graph.add_edge(ticker1, ticker2, relation="correlated", weight=round(correlation, 2))
    # Add industry-based relationships
    for ticker1, info1 in metadata.items():
        for ticker2, info2 in metadata.items():
            if ticker1 != ticker2 and info1.get("industry") == info2.get("industry"):
                graph.add_edge(ticker1, ticker2, relation="same_industry")

    return graph

######### This function creates or updates a relationship between two nodes in the neo4j graph
def add_relationship_with_type(tx, ticker1, ticker2, relation_type, correlation=None):
    query = f"""
    MATCH (a {{ticker: $ticker1}}), (b {{ticker: $ticker2}})
    MERGE (a)-[r:{relation_type}]->(b)
    """
    if correlation is not None:
        query += " SET r.correlation = $correlation"
    tx.run(query, ticker1=ticker1, ticker2=ticker2, correlation=correlation)


#########From here the code is used to create the UI in the streamlit app #########

#########Fetch Top 100 Grossing S&P 500 Firms
# Add date inputs for timeframe selection
start_date1 = st.date_input("Select Start Date for Top 100", value=datetime(2020, 1, 1))
end_date1 = st.date_input("Select End Date for Top 100", value=datetime(2023, 12, 31))

# Convert selected dates to timezone-naive
start_date1 = pd.Timestamp(start_date1).tz_localize(None)
end_date1 = pd.Timestamp(end_date1).tz_localize(None)

if st.button("Fetch Top 100 Grossing S&P 500 Firms"):
    # Fetch market caps to get the top 100 tickers
    market_caps_df = fetch_market_caps(tickers)
    st.session_state["market_caps_df"] = market_caps_df  # Store data in session state
    st.write(market_caps_df)

    # Fetch and filter stock data for the selected timeframe
    stock_data = fetch_stock_data(
        market_caps_df["Ticker"].tolist(),
        start_date1,
        end_date1
    )
    st.session_state["stock_data"] = stock_data

    # Display line chart for the selected timeframe
    st.line_chart(stock_data)

# Allow the agent to answer user queries about the data
st.subheader("Ask the Agent About the Top 100 Firms")
user_query = st.text_input("Type your question about the data (e.g., 'Which company has the highest market cap?')")

if user_query and "market_caps_df" in st.session_state:
    # Format the data as a summary for OpenAI
    data_summary = st.session_state["market_caps_df"].to_string(index=False)

    # Create the prompt for OpenAI
    prompt = (
        f"Here is a table of the top 100 grossing S&P 500 firms with their tickers and market capitalizations:\n\n"
        f"{data_summary}\n\n"
        f"Answer the following question based on the data:\n{user_query}"
    )

    # Call OpenAI API to get the response
    try:
        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",
            messages=[
                {"role": "system", "content": "You are an AI assistant skilled at analyzing financial data."},
                {"role": "user", "content": prompt}
            ]
        )
        agent_answer = response["choices"][0]["message"]["content"]
        st.subheader("Agent's Answer:")
        st.write(agent_answer)
    except Exception as e:
        st.error(f"Error with OpenAI API: {e}")


#########Analysing top 5 stocks to buy and sell
st.subheader("Analysing top 5 stocks to buy and sell")

# Add date inputs for timeframe selection
start_date = st.date_input("Select Start Date for Top 5", value=datetime(2020, 1, 1))
end_date = st.date_input("Select End Date for Top 5", value=datetime(2023, 12, 31))

start_date = pd.Timestamp(start_date).tz_localize(None)
end_date = pd.Timestamp(end_date).tz_localize(None)

if st.button("Analyze Top 5 Stocks to Buy and Sell"):
    stock_data = st.session_state.get("stock_data")
    if stock_data is not None and not stock_data.empty:
        # Ensure stock_data index is timezone-naive
        stock_data.index = stock_data.index.tz_localize(None)

        # Filter stock data for the selected timeframe
        filtered_data = stock_data.loc[start_date:end_date]

        # Analyze the filtered stock data
        top_to_buy, top_to_sell = analyze_stocks_for_buy_and_sell(filtered_data)

        # Display top stocks to buy and sell
        st.subheader("Top 5 Stocks to Buy:")
        st.write(top_to_buy)
        st.subheader("Top 5 Stocks to Sell:")
        st.write(top_to_sell)

        # Combine top 5 to buy and sell into a single DataFrame for visualization
        combined = pd.concat([top_to_buy, top_to_sell], axis=0)
        combined.index.name = "Ticker"
        combined.name = "Performance (%)"

        # Bar Plot of Top 5 to Buy and Sell
        st.subheader("Bar Plot: Top 5 Stocks to Buy and Sell")
        st.bar_chart(combined)

        # Line Chart of Historical Prices for Top 5 to Buy and Sell
        st.subheader("Line Chart: Historical Prices of Top 5 to Buy and Sell")
        selected_tickers = top_to_buy.index.tolist() + top_to_sell.index.tolist()
        historical_prices = filtered_data[selected_tickers]
        st.line_chart(historical_prices)

        # OpenAI Explanation
        explanation = generate_openai_explanation(top_to_buy, top_to_sell)
        st.subheader("AI Explanation:")
        st.write(explanation)
    else:
        st.warning("No stock data available. Please fetch the stock data first.")

#########Generate and Visualize Network Graph for GNN
st.subheader("Generate and Visualize Network Graph for GNN")
if st.button("Generate and Visualize GNN Network Graph"):
    """
    Create and enhance a NetworkX graph for GNN with stock data correlations.

    Args:
        stock_data (pd.DataFrame): Stock prices data.
        correlation_threshold (float): Minimum correlation to include an edge.

    Returns:
        torch_geometric.data.Data: PyTorch Geometric Data object.
    """
    
    stock_data = st.session_state.get("stock_data")
    if stock_data is not None:
        # Generate the graph
        pyg_graph = enhance_graph_for_gnn(stock_data)
        st.session_state["gnn_graph_data"] = pyg_graph

        # Display graph details
        st.write("GNN-compatible Network Graph Generated:")
        st.write(f"Number of Nodes: {pyg_graph.num_nodes}")
        st.write(f"Number of Edges: {pyg_graph.num_edges}")
        st.write("Node Features Shape:", pyg_graph.x.shape)

        # Visualize the graph
        # Convert PyTorch Geometric data back to NetworkX for visualization
        nx_graph = nx.Graph()
        edge_index = pyg_graph.edge_index.numpy()
        nx_graph.add_edges_from([(edge_index[0, i], edge_index[1, i]) for i in range(edge_index.shape[1])])

        # Draw the graph
        plt.figure(figsize=(10, 10))
        pos = nx.spring_layout(nx_graph, seed=42)  # Use a layout for better visualization
        nx.draw(
            nx_graph, pos, with_labels=True, node_size=500, node_color="skyblue", edge_color="gray", font_size=8
        )
        plt.title("GNN-Compatible Network Graph")
        st.pyplot(plt)
    else:
        st.warning("No stock data available. Please fetch the stock data first.")

#########Generate Knowledge Graph Data (for Neo4j)
st.subheader("Generate Knowledge Graph Data (for Neo4j)")
if st.button("Generate Knowledge Graph Data"):
    stock_data = st.session_state.get("stock_data")
    if stock_data is not None and not stock_data.empty:
        # Fetch metadata for the top 100 firms
        market_caps_df = fetch_market_caps(tickers)
        top_100_tickers = market_caps_df["Ticker"].tolist()
        metadata = fetch_metadata(top_100_tickers)

        # Generate the knowledge graph
        knowledge_graph = create_knowledge_graph(stock_data, metadata)

        # Store knowledge_graph in session_state for later pushing to Neo4j
        st.session_state["knowledge_graph"] = knowledge_graph
        st.success("Knowledge graph data generated successfully.")
    else:
        st.warning("No stock data available. Please fetch the stock data first.")

#########Generate Knowledge Graph in Neo4j
st.subheader("Generate Knowledge Graph in Neo4j")
if st.button("Push Knowledge Graph to Neo4j"):
    knowledge_graph = st.session_state.get("knowledge_graph", None)
    if knowledge_graph:
        with driver.session() as session:
            # Push nodes with metadata to Neo4j
            for node, data in knowledge_graph.nodes(data=True):
                session.write_transaction(add_node, "Stock", data)

            # Push relationships with types to Neo4j
            for edge in knowledge_graph.edges(data=True):
                ticker1, ticker2, attributes = edge
                relation_type = attributes.get("relation", "RELATED")
                correlation = attributes.get("weight", None)
                session.write_transaction(
                    add_relationship_with_type, ticker1, ticker2, relation_type, correlation
                )
        st.success("Knowledge Graph successfully pushed to Neo4j!")
    else:
        st.warning("No knowledge graph data available. Please generate the knowledge graph data first.")

######### Chatbot Assistant in the buttom of the app to be able to ask questions and get quick answers thrueout the use of the app
st.header("Chatbot Assistant")
if "messages" not in st.session_state:
    st.session_state["messages"] = []
user_input = st.chat_input("Type your message here...")
if user_input:
    st.session_state["messages"].append({"role": "user", "content": user_input})
    with st.chat_message("user"):
        st.write(user_input)
    try:
        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",
            messages=st.session_state["messages"]
        )
        bot_reply = response["choices"][0]["message"]["content"]
        st.session_state["messages"].append({"role": "assistant", "content": bot_reply})
        with st.chat_message("assistant"):
            st.write(bot_reply)
    except Exception as e:
        st.error(f"Error: {e}")